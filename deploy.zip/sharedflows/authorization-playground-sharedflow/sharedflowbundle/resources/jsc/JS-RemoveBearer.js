var bearerToken = context.getVariable("request.header.authorization");

if(bearerToken !== null && bearerToken !== ""){
    // tokens start with e, so if token is presented without "Bearer " skip this function.
    if(bearerToken.charAt(0) != "e" && bearerToken.length > 7){
        var token = bearerToken.substring(7);
        context.setVariable("request.header.authorization", token);
    }
}