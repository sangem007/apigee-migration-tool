var correlationId = Guid.newGuid();

context.setVariable("request.header.correlationId", correlationId);
